*<span style="color:red">Computer Programming F18</span>*
# Test Cases 20181125

## benchmark circuits
* 22 benchmark circuits

## test pattern sets
* For each benchmark circuit, there are two pattern sets: one with one 100 patterns and the other with 200 patterns.
* Pattern files have the ".pat" extension.

## reference test responses
* Each pattern set also comes with a reference response file, with the extension ".rop".
* At the end of the "rop" file, you can see the simulation time (on my notebook) -- just for your reference.